#include <WiFi.h>
#include <PubSubClient.h>

const char* ssid = "Wokwi-GUEST";
const char* password = "";

// IP local
const char* mqtt_server = "broker.hivemq.com";

WiFiClient espClient;
PubSubClient client(espClient);

// Pines
const int btnCorrect = 15;
const int btnWrong = 4;
const int btnReset = 5;

const int ledGreen = 18;
const int ledYellow = 19;
const int ledRed = 21;

int failedAttempts = 0;


void setup() {
  pinMode(btnCorrect, INPUT_PULLUP);
  pinMode(btnWrong, INPUT_PULLUP);
  pinMode(btnReset, INPUT_PULLUP);

  pinMode(ledGreen, OUTPUT);
  pinMode(ledYellow, OUTPUT);
  pinMode(ledRed, OUTPUT);

  Serial.begin(115200);

  WiFi.begin(ssid, password);
  Serial.print("Conectando a WiFi");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println(" conectado!");

  client.setServer(mqtt_server, 1883);

  randomSeed(micros());

}

void reconnect() {
  if (client.connected()) return;

  Serial.print("Intentando conectar a MQTT...");

  String clientId = "ESP32Client-" + String(random(1000, 9999));

   if (client.connect(clientId.c_str())) {
    Serial.println(" conectado!");
  } else {
    Serial.print(" fallo, rc=");
    Serial.println(client.state());
  }
}

void loop() {

  client.loop();

  if (!client.connected()) {
    reconnect();
    delay(1000); // evita spam
    return;
  }
  
  // RESET
  if (digitalRead(btnReset) == LOW) {
    failedAttempts = 0;

    digitalWrite(ledGreen, LOW);
    digitalWrite(ledYellow, LOW);
    digitalWrite(ledRed, LOW);

    client.publish("iot/access/reset", "{\"event\":\"reset\"}");


    Serial.println("Sistema reiniciado");
    Serial.print("Intentos: ");
    Serial.println(failedAttempts);
    delay(400);
    return;
  }

  // Apagar LEDs por defecto
  digitalWrite(ledGreen, LOW);
  digitalWrite(ledYellow, LOW);

  // BOTÓN CORRECTO
  if (digitalRead(btnCorrect) == LOW) {
    digitalWrite(ledGreen, HIGH);
    failedAttempts = 0;

    client.publish("iot/access/granted", "{\"access\":\"granted\"}");

    Serial.println("✅Acceso autorizado");
    delay(400);
  }

  // BOTÓN INCORRECTO
  if (digitalRead(btnWrong) == LOW) {
    digitalWrite(ledYellow, HIGH);
    failedAttempts++;

    client.publish("iot/access/denied", "{\"access\":\"denied\"}");

    Serial.println("❌Acceso no autorizado");
    Serial.print("Intentos: ");
    Serial.println(failedAttempts);

    if (failedAttempts >= 3) {
      digitalWrite(ledRed, HIGH);

      client.publish("iot/access/events", "{\"intruder\":true}");

      Serial.println("🚨 INTRUSO DETECTADO");
    }

    delay(400);
  }
}